Please read the Cordova [Hooks Guide](https://cordova.apache.org/docs/en/latest/guide/appdev/hooks/) to learn how to hook into Cordova CLI commands.
